#! /usr/bin/python
CACHE_TTL = 60
UPDATE_LIBRARY_INTERVAL = 4*60*60

if __name__ == "__main__":
    import xml.etree.ElementTree as ET
    tree = ET.parse('resources/settings.xml')
    ids = filter(None, [item.get('id') for item in tree.findall('.//setting')])
    content = []
    with open(__file__, "r") as me:
        content = me.readlines()
        content = content[:content.index("#GENERATED\n")+1]
    with open(__file__, 'w') as f:
        f.writelines(content)
        for _id in ids:
            line = "SETTING_{0} = \"{1}\"\n".format(_id.upper(), _id)
            f.write(line)    

#GENERATED
SETTING_LANGUAGE_ID = "language_id"
SETTING_STYLE = "style"
SETTING_STYLE_FOLDER = "style_custom_folder"
SETTING_VIEW_ENABLED = "force_view"
SETTING_VIEW_MAIN = "main_view"
SETTING_VIEW_MOVIES = "movies_view"
SETTING_VIEW_TV = "tvshows_view"
SETTING_VIEW_MUSIC = "music_view"
SETTING_VIEW_LIVE = "live_view"
SETTING_VIEW_LIST = "list_view"
SETTING_BACKGROUND = "background"
SETTING_BACKGROUND_FOLDER = "background_custom_folder"
SETTING_LIBRARY_UPDATES = "library_updates"
SETTING_PLAYERS_UPDATE_URL = "players_update_url"
SETTING_MOVIES_ENABLED_PLAYERS = "movies_enabled_players"
SETTING_MOVIES_DEFAULT_PLAYER = "movies_default_player"
SETTING_MOVIES_DEFAULT_PLAYER_FROM_LIBRARY = "movies_default_player_from_library"
SETTING_MOVIES_DEFAULT_PLAYER_FROM_CONTEXT = "movies_default_player_from_context"
SETTING_MOVIES_LIBRARY_FOLDER = "movies_library_folder"
SETTING_MOVIES_PLAYLIST_FOLDER = "movies_playlist_folder"
SETTING_TV_ENABLED_PLAYERS = "tv_enabled_players"
SETTING_TV_DEFAULT_PLAYER = "tv_default_player"
SETTING_TV_DEFAULT_PLAYER_FROM_LIBRARY = "tv_default_player_from_library"
SETTING_TV_DEFAULT_PLAYER_FROM_CONTEXT = "tv_default_player_from_context"
SETTING_TV_LIBRARY_FOLDER = "tv_library_folder"
SETTING_TV_PLAYLIST_FOLDER = "tv_playlist_folder"
SETTING_LIVE_ENABLED_PLAYERS = "live_enabled_players"
SETTING_LIVE_DEFAULT_PLAYER = "live_default_player"
SETTING_LIVE_DEFAULT_PLAYER_FROM_LIBRARY = "live_default_player_from_library"
SETTING_LIVE_DEFAULT_PLAYER_FROM_CONTEXT = "live_default_player_from_context"
SETTING_LIVE_LIBRARY_FOLDER = "live_library_folder"
SETTING_LIVE_PLAYLIST_FOLDER = "live_playlist_folder"
SETTING_MUSICVIDEOS_ENABLED_PLAYERS = "musicvideos_enabled_players"
SETTING_MUSICVIDEOS_DEFAULT_PLAYER = "musicvideos_default_player"
SETTING_MUSICVIDEOS_DEFAULT_PLAYER_FROM_LIBRARY = "musicvideos_default_player_from_library"
SETTING_MUSICVIDEOS_DEFAULT_PLAYER_FROM_CONTEXT = "musicvideos_default_player_from_context"
SETTING_MUSICVIDEOS_LIBRARY_FOLDER = "musicvideos_library_folder"
SETTING_MUSICVIDEOS_PLAYLIST_FOLDER = "musicvideos_playlist_folder"
SETTING_PREFERRED_MUSIC_TYPE = "preferred_music_type"
SETTING_MUSIC_ENABLED_PLAYERS = "music_enabled_players"
SETTING_MUSIC_DEFAULT_PLAYER = "music_default_player"
SETTING_MUSIC_DEFAULT_PLAYER_FROM_LIBRARY = "music_default_player_from_library"
SETTING_MUSIC_DEFAULT_PLAYER_FROM_CONTEXT = "music_default_player_from_context"
SETTING_MUSIC_LIBRARY_FOLDER = "music_library_folder"
SETTING_MUSIC_PLAYLIST_FOLDER = "music_playlist_folder"
SETTING_LIBRARY_SET_DATE = "library_set_date"
SETTING_USE_SIMPLE_SELECTOR = "use_simple_selector"
SETTING_AUTO_HIDE_DIALOGS = "auto_hide_dialogs"
SETTING_AUTO_HIDE_DIALOGS_PROGRESS = "auto_hide_dialogs_progress"
SETTING_AUTO_HIDE_DIALOGS_INFO = "auto_hide_dialogs_info"
SETTING_AUTO_HIDE_DIALOGS_KEYBOARD = "auto_hide_dialogs_keyboard"
SETTING_POOL_SIZE = "pool_size"
SETTING_TRAKT_ACCESS_TOKEN = "trakt_access_token"
SETTING_TRAKT_REFRESH_TOKEN = "trakt_refresh_token"
SETTING_TRAKT_EXPIRES_AT = "trakt_expires_at"
SETTING_TOTAL_SETUP_DONE = "total_setup_done"
SETTING_MOVIES_PLAY_BY_ADD = "movies_played_by_add"
SETTING_TV_PLAY_BY_ADD = "tvshows_played_by_add"
SETTING_TRAKT_PERIOD = "trakt_period"
